/*
 * @Description: 后端请求路径封装
 * @Version: 2.0
 * @Autor: wuwei3
 * @Date: 2020-01-16 14:02:00
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-06-08 15:30:38
 */
import axios from 'axios';
import router from '@/router/index.js';
import { Message } from 'element-ui';
import Storage from '@/utils/storage';

const storage = new Storage();
const service = axios.create({
  baseURL: '/service',
});

/**
 * @description:  开始请求
 * @param {config} 请求内容，字段 + 头 +其他
 * @return:
 */
service.interceptors.request.use(
  (config) => {
    let token = storage.get('token');

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    getResponse(error.data);
  }
);

/**
 * @description: 请求响应
 * @param {type}
 * @return:
 */
service.interceptors.response.use(
  (response) => {
    return Promise.resolve(response.data);
  },
  (error) => {
    return getResponse(error.response) || Promise.reject();
  }
);

/**
 * @description:  异常处理返回值
 * @param {res}  返回值内容
 * @return: 封装好返回值内容
 */
function getResponse(res) {
  switch (res.status) {
    case 500:
      router.push({ name: 'error', params: { id: 2 } });
      break;
    case 502:
      router.push({ name: 'error', params: { id: 2 } });
      break;
    case 504:
      router.push({ name: 'error', params: { id: 3 } });
      break;
    case 404:
      router.push({ name: 'error', params: { id: 1 } });
      break;
    case 401: {
      window.location.href = '/console/login';
      break;
    }
    case 403:
      // 未授权
      Promise.reject(res.data);
      break;
    case 400:
      // 未授权
      Message.error(res.data.message);
      break;
    default:
      break;
  }
}

export default service;
