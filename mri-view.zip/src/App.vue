<!--
 * @Description: 路由分发,页面挂载
 * @Version: 2.0
 * @Autor: wuwei3
 * @Date: 2020-03-25 09:40:18
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-08-20 11:26:20
 -->
<template>
  <div id="app" class="app">
    <router-view />
  </div>
</template>
